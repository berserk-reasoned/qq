package com.example.spoofer;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import rikka.shizuku.Shizuku;

public class MainActivity extends AppCompatActivity {

    private LocationManager locationManager;
    private EditText latInput, lonInput;
    private Button startSpoofBtn;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        latInput = findViewById(R.id.editLatitude);
        lonInput = findViewById(R.id.editLongitude);
        startSpoofBtn = findViewById(R.id.buttonSpoof);
        statusText = findViewById(R.id.statusText);

        checkEnvironment();

        startSpoofBtn.setOnClickListener(v -> {
            if (!Shizuku.isPreV11() && Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(0);
                Toast.makeText(this, "Requesting Shizuku permission", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!hasLocationPermission()) {
                Toast.makeText(this, "Location permission not granted", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
                String provider = LocationManager.GPS_PROVIDER;

                if (locationManager.getProvider(provider) == null) {
                    locationManager.addTestProvider(provider, false, false, false, false,
                            true, true, true, 0, 5);
                }

                locationManager.setTestProviderEnabled(provider, true);

                Location location = new Location(provider);
                location.setLatitude(Double.parseDouble(latInput.getText().toString()));
                location.setLongitude(Double.parseDouble(lonInput.getText().toString()));
                location.setAccuracy(1);
                location.setTime(System.currentTimeMillis());

                locationManager.setTestProviderLocation(provider, location);

                Toast.makeText(this, "Location spoofed successfully!", Toast.LENGTH_SHORT).show();
                statusText.setText("✅ Location spoof active.");
            } catch (Exception e) {
                statusText.setText("❌ Spoof failed: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }

    private boolean hasLocationPermission() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void checkEnvironment() {
        StringBuilder status = new StringBuilder();

        if (Shizuku.isPreV11() || Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            status.append("✅ Shizuku Permission Granted\n");
        } else {
            status.append("❌ Shizuku Not Granted\n");
        }

        if (hasLocationPermission()) {
            status.append("✅ Location Permission Granted\n");
        } else {
            status.append("❌ Location Permission Missing\n");
        }

        statusText.setText(status.toString());
    }
}